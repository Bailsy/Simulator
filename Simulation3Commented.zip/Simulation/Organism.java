/**
 * This class includes all types of organisms in the simulation.
 *
 * @author Nicolás Alcalá Olea and Bailey Crossan
 */
public interface Organism
{
}
